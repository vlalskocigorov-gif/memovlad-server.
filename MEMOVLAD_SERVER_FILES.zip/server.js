const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const crypto = require('crypto');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*', methods: ['GET', 'POST'] }, transports: ['websocket', 'polling'] });
const PORT = process.env.PORT || 10000;
const rooms = new Map();
const roomCode = () => 'EUROPA-' + crypto.randomInt(100000, 1000000);
const members = room => [...room.players.values()].map(p => ({ id: p.id, name: p.name, host: p.id === room.hostId }));
const cleanName = n => String(n || 'Игрок').trim().slice(0, 24) || 'Игрок';

app.get('/', (_req, res) => res.status(200).send('MEMOVLAD EVROPE MAP multiplayer server is running.'));
app.get('/health', (_req, res) => res.json({ ok: true, rooms: rooms.size }));

io.on('connection', socket => {
  socket.data.roomCode = null;

  socket.on('createRoom', (data = {}, ack = () => {}) => {
    if (socket.data.roomCode) leaveRoom(socket);
    let code; do { code = roomCode(); } while (rooms.has(code));
    const room = { code, hostId: socket.id, players: new Map(), snapshot: null, started: false };
    room.players.set(socket.id, { id: socket.id, name: cleanName(data.name) });
    rooms.set(code, room);
    socket.data.roomCode = code;
    socket.join(code);
    ack({ ok: true, code, members: members(room) });
    socket.to(code).emit('membersUpdate', { members: members(room) });
  });

  socket.on('joinRoom', (data = {}, ack = () => {}) => {
    const code = String(data.code || '').trim().toUpperCase();
    const room = rooms.get(code);
    if (!room) return ack({ ok: false, error: 'Такого кода комнаты не существует.' });
    if (room.players.size >= 8) return ack({ ok: false, error: 'Комната заполнена (максимум 8 игроков).' });
    if (socket.data.roomCode) leaveRoom(socket);
    const player = { id: socket.id, name: cleanName(data.name) };
    room.players.set(socket.id, player);
    socket.data.roomCode = code;
    socket.join(code);
    ack({ ok: true, code, members: members(room), snapshot: room.snapshot, started: room.started });
    socket.to(code).emit('playerJoined', { id: socket.id, name: player.name });
    io.to(code).emit('membersUpdate', { members: members(room) });
  });

  socket.on('roomBroadcast', message => {
    const code = socket.data.roomCode;
    const room = code && rooms.get(code);
    if (!room || room.hostId !== socket.id || !message || typeof message !== 'object') return;
    if (message.type === 'snapshot') room.snapshot = message.data;
    if (message.type === 'start') room.started = true;
    socket.to(code).emit('roomMessage', message);
    if (message.type === 'closed') closeRoom(code);
  });

  socket.on('toHost', message => {
    const code = socket.data.roomCode;
    const room = code && rooms.get(code);
    if (!room || room.hostId === socket.id || !message || typeof message !== 'object') return;
    const host = io.sockets.sockets.get(room.hostId);
    if (host) host.emit('roomMessage', { ...message, name: cleanName(room.players.get(socket.id)?.name) });
  });

  socket.on('leaveRoom', () => leaveRoom(socket));
  socket.on('disconnect', () => leaveRoom(socket));
});

function closeRoom(code) {
  const room = rooms.get(code);
  if (!room) return;
  for (const id of room.players.keys()) {
    const s = io.sockets.sockets.get(id);
    if (s) { s.emit('roomMessage', { type: 'closed' }); s.leave(code); s.data.roomCode = null; }
  }
  rooms.delete(code);
}
function leaveRoom(socket) {
  const code = socket.data.roomCode;
  if (!code) return;
  const room = rooms.get(code);
  socket.data.roomCode = null;
  socket.leave(code);
  if (!room) return;
  const wasHost = room.hostId === socket.id;
  room.players.delete(socket.id);
  if (wasHost) {
    // Keep the room alive only if another player can become host.
    const next = room.players.values().next().value;
    if (next) room.hostId = next.id;
    else { rooms.delete(code); return; }
  }
  io.to(code).emit('playerLeft', { id: socket.id });
  io.to(code).emit('membersUpdate', { members: members(room) });
}

server.listen(PORT, '0.0.0.0', () => console.log(`MEMOVLAD multiplayer server listening on ${PORT}`));
